/*
 * @Descripttion: 
 * @version: 
 * @Author: Chen
 * @Date: 2021-11-01 20:44:13
 * @LastEditors: Chen
 * @LastEditTime: 2021-11-01 20:45:38
 */
import React, { Component } from 'react'
// import './home.styl'

class Home extends Component {
    render() {
        return (
            <div className="P-home">
                <h1>Home page</h1>
            </div>
        )
    }
}

export default Home