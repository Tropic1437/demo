/*
 * @Descripttion: 
 * @version: 
 * @Author: Chen
 * @Date: 2021-11-01 20:46:12
 * @LastEditors: Chen
 * @LastEditTime: 2021-11-01 20:48:15
 */
import React, { Component } from 'react'
// import './login.styl'

class Login extends Component {
    render() {
        return (
            <div className="P-login">
                <h1>Login page</h1>
            </div>
        )
    }
}

export default Login