/*
 * @Descripttion: 
 * @version: 
 * @Author: Chen
 * @Date: 2021-11-01 20:38:58
 * @LastEditors: Chen
 * @LastEditTime: 2021-11-01 20:38:58
 */
import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

ReactDOM.render(<App />, document.getElementById('root'))