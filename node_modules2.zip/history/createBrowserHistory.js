'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('createBrowserHistory');
module.exports = require('./index.js').createBrowserHistory;
