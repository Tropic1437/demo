'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('LocationUtils');
module.exports = require('./index.js').LocationUtils;
