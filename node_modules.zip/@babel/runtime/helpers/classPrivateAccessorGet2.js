var classCheckPrivateInstanceAccess2 = require("./classCheckPrivateInstanceAccess2.js");

function _classPrivateAccessorGet2(receiver, privateSet, fn) {
  classCheckPrivateInstanceAccess2(receiver, privateSet, "get");
  return fn.call(receiver);
}

module.exports = _classPrivateAccessorGet2;
module.exports["default"] = module.exports, module.exports.__esModule = true;