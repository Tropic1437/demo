var classCheckPrivateInstanceAccess2 = require("./classCheckPrivateInstanceAccess2.js");

function _classPrivateFieldSet2(receiver, privateMap, value) {
  classCheckPrivateInstanceAccess2(receiver, privateMap, "set");
  privateMap.set(receiver, value);
  return value;
}

module.exports = _classPrivateFieldSet2;
module.exports["default"] = module.exports, module.exports.__esModule = true;