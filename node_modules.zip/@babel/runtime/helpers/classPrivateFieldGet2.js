var classCheckPrivateInstanceAccess2 = require("./classCheckPrivateInstanceAccess2.js");

function _classPrivateFieldGet2(receiver, privateMap) {
  classCheckPrivateInstanceAccess2(receiver, privateMap, "get");
  return privateMap.get(receiver);
}

module.exports = _classPrivateFieldGet2;
module.exports["default"] = module.exports, module.exports.__esModule = true;