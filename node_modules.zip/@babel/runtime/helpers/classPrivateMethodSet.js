function _classPrivateMethodSet() {
  throw new TypeError("attempted to reassign private method");
}

module.exports = _classPrivateMethodSet;
module.exports["default"] = module.exports, module.exports.__esModule = true;