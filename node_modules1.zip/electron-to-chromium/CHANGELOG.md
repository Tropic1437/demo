v1.3.0
  * Additionally include chromium to electron mappings

v1.2.0
  * versions and full-versions are now separately importable.

v1.1.0
  * Both electronToChromium and electronToBrowserList now can accept strings as well as numbers.

v1.0.1
  Update documentation

v1.0.0
  Inititial release
