const set = require('regenerate')();
set.addRange(0xA500, 0xA62B);
module.exports = set;
