const set = require('regenerate')();
set.addRange(0x1980, 0x19AB).addRange(0x19B0, 0x19C9).addRange(0x19D0, 0x19DA).addRange(0x19DE, 0x19DF);
module.exports = set;
