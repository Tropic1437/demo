"use strict";
require("./warnAboutDeprecatedCJSRequire")("generatePath");
module.exports = require("./index.js").generatePath;
